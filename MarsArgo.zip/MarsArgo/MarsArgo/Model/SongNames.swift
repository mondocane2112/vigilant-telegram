//
//  SongNames.swift
//  MarsArgo
//
//  Created by Dude Bro Dude on 3/31/18.
//  Copyright © 2018 Dude Bro Dude. All rights reserved.
//

import Foundation

enum SongNames: String {
    case usingyou
    case runaway
    case loveblackwhite
}
